package com.example.submission3.ui.activity

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.submission3.R
import com.example.submission3.adapter.SectionPagerAdapter
import com.example.submission3.database.DatabaseContract
import com.example.submission3.database.UserHelper
import com.example.submission3.databinding.ActivityDetailUserBinding
import com.example.submission3.model.User
import com.example.submission3.viewModel.DetailUserViewModel
import com.google.android.material.tabs.TabLayoutMediator

class DetailUserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_USER = "extra_user"
        const val EXTRA_TYPE = "extra_type"

        @StringRes
        private val TAB_TITLES = intArrayOf(
                R.string.follower,
                R.string.following
        )
    }

    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var detailUserViewModel: DetailUserViewModel
    private lateinit var userHelper: UserHelper
    private var user: User? = null
    private var position: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val detailUser = intent.getParcelableExtra<User>(EXTRA_USER) as User
        val getUser = detailUser.username

        var statusFavorite = false

        user = intent.getParcelableExtra(EXTRA_USER)

        supportActionBar?.title = getUser

        getDetailUser(getUser!!)
        viewPagerConfig()

        userHelper = UserHelper.getInstance(applicationContext)
        userHelper.open()

        setStatusFavorite(statusFavorite)
        binding.fabFavorite.setOnClickListener {
            statusFavorite = !statusFavorite
            //Kode untuk insert database
            addUserToFavorite()
            setStatusFavorite(statusFavorite)
        }
    }

    private fun getDetailUser(getUser: String) {
        detailUserViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DetailUserViewModel::class.java)
        detailUserViewModel.setUserDetail(getUser, this)
        detailUserViewModel.getUserDetail().observe(this, Observer {
            binding.tvUsername.text   = it.username
            binding.tvType.text = it.type
            binding.tvCompany3.text = it.company
            binding.tvRepository3.text  = it.repository
            binding.tvRepository3.text  = it.location
            Glide.with(this)
                .load(it.avatar)
                .into(binding.imgAvatar)

            showLoading(false)
        })
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun viewPagerConfig() {
        val sectionPagerAdapter = SectionPagerAdapter(this, this)
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionPagerAdapter
        TabLayoutMediator(binding.tabLayout, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f
    }

    private fun setStatusFavorite(statusFavorite: Boolean) {
        if (statusFavorite) {
            addUserToFavorite()
            binding.fabFavorite.setImageResource(R.drawable.ic_baseline_favorite_24)
            Toast.makeText(this, "Add to Favorite", Toast.LENGTH_SHORT).show()
        }else{
            binding.fabFavorite.setImageResource(R.drawable.ic_baseline_favorite_border_24)
        }
    }

    private fun addUserToFavorite() {
        val username = binding.tvUsername.text.toString()
        val type = binding.tvType.text.toString()

        user?.username = username
        user?.type = type

        val values = ContentValues()
        values.put(DatabaseContract.FavoriteColumns.COLUMNS_USERNAME, username)
        values.put(DatabaseContract.FavoriteColumns.COLUMNS_TYPE, type)
    }
}