package com.example.submission3.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.submission3.database.UserHelper
import com.example.submission3.databinding.ActivityFavoriteBinding
import com.example.submission3.model.User

class FavoriteActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_USER = "extra_user"
        const val EXTRA_POSITION = "extra_position"
        const val REQUEST_ADD = 100
        const val RESULT_ADD = 101
        const val RESULT_DELETE = 201
    }

    private var user: User? = null
    private var position: Int = 0
    private lateinit var userHelper: UserHelper
    private lateinit var  binding: ActivityFavoriteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userHelper = UserHelper.getInstance(applicationContext)
        userHelper.open()

        user = intent.getParcelableExtra(EXTRA_USER)
        if (user != null) {
            position = intent.getIntExtra(EXTRA_POSITION, 0)
        }else{
            user = User()
        }
    }
}