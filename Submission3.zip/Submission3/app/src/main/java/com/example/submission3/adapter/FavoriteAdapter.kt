package com.example.submission3.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.submission3.CustomOnItemClickListener
import com.example.submission3.R
import com.example.submission3.databinding.ItemFavoriteBinding
import com.example.submission3.databinding.ItemRowGithubBinding
import com.example.submission3.model.User
import com.example.submission3.ui.activity.FavoriteActivity

class FavoriteAdapter: RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>() {

    var listFavorite = ArrayList<User>()
    set(listFavorite) {
        if (listFavorite.size > 0) {
            this.listFavorite.clear()
        }
        this.listFavorite.addAll(listFavorite)
        notifyDataSetChanged()
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_row_github, parent, false)
        return FavoriteViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        holder.bind(listFavorite[position])
    }

    override fun getItemCount(): Int = this.listFavorite.size

    inner class FavoriteViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private val binding = ItemFavoriteBinding.bind(itemView)
        fun bind(user: User) {
            binding.tvUsername.text = user.username
            binding.tvType.text = user.type
            Glide.with(itemView)
                    .load(user.avatar)
                    .into(binding.imgPhotoUser)
        }
    }

    fun addFavorite(user: User) {
        this.listFavorite.add(user)
        notifyItemInserted(this.listFavorite.size - 1)
    }

    fun removeFavorite(position: Int) {
        this.listFavorite.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, this.listFavorite.size)
    }
}