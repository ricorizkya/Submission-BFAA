package com.example.submission3.ui.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submission3.adapter.ListUserAdapter
import com.example.submission3.databinding.ActivityMainBinding
import com.example.submission3.model.User
import com.example.submission3.viewModel.MainViewModel

class MainActivity : AppCompatActivity(){

    private lateinit var mainViewModel: MainViewModel
    private lateinit var adapter: ListUserAdapter
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ListUserAdapter()
        adapter.notifyDataSetChanged()

        binding.rvGithub.layoutManager = LinearLayoutManager(this)
        binding.rvGithub.adapter = adapter

        mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)

        binding.btnUser.setOnClickListener {
            val userItems = binding.editUser.text.toString()
            if (userItems.isEmpty()) return@setOnClickListener
            showLoading(true)
            mainViewModel.setUserGithub(userItems)
        }

        mainViewModel.getUserGithub().observe(this, { user ->
            if (user != null) {
                adapter.setData(user)
                adapter.setOnItemClickCallback(object :
                        ListUserAdapter.OnItemClickCallback {
                    override fun onItemClicked(user: User) {
                        showSelectedData(user)
                    }
                })
                showLoading(false)
            }
        })
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun showSelectedData(user: User) {
        val dataUser = User(
                user.id,
                user.username,
                user.follower,
                user.following,
                user.repository,
                user.location,
                user.company,
                user.avatar,
                user.type
        )

        val intent = Intent(this@MainActivity, DetailUserActivity::class.java)
        intent.putExtra(DetailUserActivity.EXTRA_USER, dataUser)
        startActivity(intent)
    }
}